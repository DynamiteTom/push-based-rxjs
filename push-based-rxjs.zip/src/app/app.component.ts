import { Component, ChangeDetectionStrategy } from '@angular/core';
import { FormControl } from '@angular/forms';

import { Observable } from 'rxjs';
import { take, debounceTime, distinctUntilChanged } from 'rxjs/operators';

import { UserFacade, Pagination } from './user.facade';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'push-based-rxjs';
  showButton = true;
  pagination$ : Observable<Pagination>;
  searchTerm = new FormControl();

  constructor(public users: UserFacade) { }

  ngOnInit() {
    this.users.criteria$.pipe(take(1)).subscribe(criteria => {
      this.searchTerm.patchValue(criteria, { emitEvent: false });
    });

    this.searchTerm.valueChanges.pipe(
      debounceTime(300),
      distinctUntilChanged()
    ).subscribe(value => this.users.updateSearchCriteria(value));
  }

  getPageSize() {
    this.pagination$ = this.users.pagination$;
    this.showButton = false;
  }
}

